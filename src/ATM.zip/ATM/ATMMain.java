package ATM;

public class ATMMain {
        public static void main(String[] args) {
                ATMActor atmMain = new ATMActor();
                atmMain.MainScreen(); // 실행문
        }
}
