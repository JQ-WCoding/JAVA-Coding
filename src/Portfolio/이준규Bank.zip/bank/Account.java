package Portfolio.bank;

public class Account {
    int clientNo;
    String accountNumber;
    int money;
}
