package com.bank;

public class Client {
    int clientNo;
    String id;
    String pwd;
    String name;
}
