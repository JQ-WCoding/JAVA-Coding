package com.bank;

public class AccountManager {
    Account[] accountList;
    int accountCount;
}
