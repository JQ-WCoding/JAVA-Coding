package com.bank;

public class Account {
    int clientNo;
    String accountNumber;
    int money;
}
