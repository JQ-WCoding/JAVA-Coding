package com.bank;

public class ClientManager {
    Client[] clientList;
    int clientCount;
}
